from zad6testy import runtests

def parking(X,Y):
  # tu prosze wpisac wlasna implementacje
  pass

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( parking, all_tests = False )
