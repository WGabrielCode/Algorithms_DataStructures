from egzP9atesty import runtests

def ASD(T, p, Q, n):
    #Tutaj proszę wpisać własną implementację
    return 0


#Podpowiedź. Format zadania jest dość nietypowy (także ze względu na sposób działania testów),
#w takiej formie żadne zadanie raczej nie powinno się pojawić na egzaminie. Zadanie ma na celu
#sprawdzenie zrozumienia struktury #### Drzewa Przedziałowego ####

runtests(sol, all_tests = True)

