from zadtesty import runtests

def goodknight( G, s, t ):
  # tu prosze wpisac wlasna implementacje
  pass

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( goodknight, all_tests = False )
