from egzP9btesty import runtests

def dyrektor( G, R ):
	#Tutaj proszę wpisać własną implementację 
	return []
	
runtests(sol, all_tests=True)
